/**
 * Created by KH2041 on 2/17/2016.
 */
angular.module('worldt20.services',[])

.factory('T20Data',function(){

    var data = tData;
    var matchesData = data.matchFixture;

    var teamsData = data.teamsDetails;
    var teamData = null;
    var teamNames = data.teamNames;
    var matchesOn = data.matchDates;

    var venueDate = data.venueDetails;

    var matchTypes = data.roundTypes;

    var teamsLogoURL = new Array();

    return {
        all : function() {
            return data;
        },

        getMatchesFixture : function() {
            return matchesData;
        },

        getMatchFixture : function() {
            //return
        },

        getTeamsDetails : function() {
            return teamsData;
        },

        getTeamDetails : function(tid) {
            for (var i = 0; i < teamsData.length; i++) {
                if (teamsData[i].teamId === tid) {
                    return teamsData[i];
                }
            }
            return null;
        },

        getVenueDetails : function() {
          return venueDate;
        },

        getTeamNames : function() {
          return teamNames;
        },

        getMatchDates : function() {
          return matchesOn;
        },

        getMatchTypes : function() {
          return matchTypes;
        },

        getTeamsLogoURL : function() {
          for (var i = 0; i < teamsData.length; i++) {                
            teamsLogoURL[i] = teamsData[i].teamLogo;                
          }
          return teamsLogoURL;
        }
    };
})

.factory('FlickrFactory', function(){
    var fs = flikrConfig;
    var fcs = flickrCountryConfig;
    var flickrTeamLogoURLs = new Array();
    var data = tData;
    var teamsData = data.teamsDetails;
    var revisedteamsData = {};

    return {
        getFlickrURL : function() {
          //https://api.flickr.com/services/rest/?method=flickr.photosets.getPhotos&api_key=d72fe8676934a2eea3d658b3128bc576&
          //photoset_id=72157665071236322&user_id=140267976%40N07&format=json&jsoncallback=JSON_CALLBACK'
          var furl = fs.flickrBaseURL+'?method='+fs.method+'&api_key='+fs.api_key+'&photoset_id='+fs.photoset_id+'&user_id='+
                  fs.user_id+'&format='+fs.format+'&jsoncallback='+fs.jsoncallback;
          console.log('The Flickr Teams URL is : ' + furl);
          return furl;
        },

        produceFlickrURLs : function(resTeamLogos) {
          console.log('Team Logos ' + resTeamLogos);
          //revisedteamsData = teamsData;
          for(var i=0; i<resTeamLogos.length; i++) {
            var photo = resTeamLogos[i];
            revisedteamsData[i] = "https://farm" + photo.farm + ".staticflickr.com/" +  photo.server + "/" + photo.id + "_" + photo.secret + "_b.jpg";

          }
          return revisedteamsData;
        },

        getFlickrCountryURL : function() {
          //https://api.flickr.com/services/rest/?method=flickr.photosets.getPhotos&api_key=d72fe8676934a2eea3d658b3128bc576&
          //photoset_id=72157665071236322&user_id=140267976%40N07&format=json&jsoncallback=JSON_CALLBACK'
          var fcurl = fs.flickrBaseURL+'?method='+fs.method+'&api_key='+fs.api_key+'&photoset_id='+fcs.photoset_id+'&user_id='+
                  fs.user_id+'&format='+fs.format+'&jsoncallback='+fs.jsoncallback;
          console.log('The Flickr Country URL is : ' + fcurl);
          return fcurl;
        },

        produceFlickrCountryURLs : function(resCountryLogos) {
          console.log('Country Flags ' + resCountryLogos);
          revisedCountryData = teamsData;
          for(var i=0; i<resCountryLogos.length; i++) {
            var photo = resCountryLogos[i];
            revisedCountryData[i].teamLogo = "https://farm" + photo.farm + ".staticflickr.com/" +  photo.server + "/" + photo.id + "_" + photo.secret + "_b.jpg";

          }
          return revisedCountryData;
        }

    };
})

.factory('HelperFunction', function(T20Data){

  return {

    prepareFullFixture : function(currentMatch) {
      var data = tData;
      var revisedTeamsLogos = new Array();
      var fullFixture = currentMatch;
      venueInfo = T20Data.getVenueDetails();
      teamNames = T20Data.getTeamNames();
      teamLogoURL = T20Data.getTeamsLogoURL();
      matchDatesOn = T20Data.getMatchDates();

      t1 = currentMatch.opp1;
      t2 = currentMatch.opp2;
      /*
      if(t1 == 'TA' || t2 == 'TA' ){
        t1 = 'T'+teamNames.length;
      }else if(t2 == '') {
        t2 = 'T'+teamNames.length;
      }
      */
      d = currentMatch.matchDate;
      v = currentMatch.venueId;
      mid = currentMatch.matchId;

      //console.log('revisedTeamsLogos ' + teamLogosList);
      
      if(t1 != undefined) {
        t1index = t1.substring(1,t1.length);
      }    
      
      fullFixture.opp1 = teamNames[t1index-1];
      if(t2 != undefined) {
        t2index = t2.substring(1,t2.length);
      }
      
      fullFixture.opp2 = teamNames[t2index-1];

      fullFixture.opp1Logo = teamLogoURL[t1index-1];
      fullFixture.opp2Logo = teamLogoURL[t2index-1];

      if(teamLogosList.length != 0) {
        //console.log('Displaying Team Logos From Flickr');
        fullFixture.opp1Logo = teamLogosList[t1index-1];
        fullFixture.opp2Logo = teamLogosList[t2index-1];
      }

      fullFixture.matchDate = matchDatesOn[(d.substring(1,d.length))-1];
      if(!isNaN(v.substring(1,v.length))) {
        fullFixture.venueId = venueInfo[(v.substring(1,v.length))-1].city;
        fullFixture.venueName = venueInfo[(v.substring(1,v.length))-1].name;
        fullFixture.lat = venueInfo[(v.substring(1,v.length))-1].lat;
        fullFixture.lng = venueInfo[(v.substring(1,v.length))-1].lng;
      }


      fullFixture.mnumber = mid.substring(1,t1.length);

      return fullFixture;
    }
  };

})

.factory('HistoryFactory', function(){
  console.log('in HistoryFactory');
  var historyData = T20History;

  return {
    getHistoryYears : function() {
      //console.log('in getHistoryYears ');
      return historyData.Year;
    },

    getHistoryHosts : function() {
      //console.log('in getHistoryHosts ');
      return historyData.Host;
    },

    getHistoryWinners : function() {
      //console.log('in getHistoryWinners ');
      return historyData.Winner;
    },

    getHistoryWinnerPics : function() {
      //console.log('in getHistoryWinnersPics ');
      return historyData.WinnerPics;
    },

    getHistoryRunners : function() {
      //console.log('in getHistoryRunners ');
      return historyData.Runner;
    },

    getHistoryResults : function() {
      //console.log('in getHistoryResults ');
      return historyData.Result;
    },

    getHistoryMOM : function() {
      //console.log('in getHistoryMOM ');
      return historyData.ManOfTheMatch;
    },

    getHistoryMOS : function() {
      //console.log('in getHistoryMOS ');
      return historyData.ManOfTheSeries;
    }

  };

});
