var flikrConfig = {
  'flickrBaseURL' : 'https://api.flickr.com/services/rest/',
  'method' : 'flickr.photosets.getPhotos',
  'api_key' : '4f3f17cc63f353af85820f16cd4129e6', //d72fe8676934a2eea3d658b3128bc576
  'photoset_id' : '72157665071236322',
  'user_id' : '140267976%40N07', //140267976@N07
  'format' : 'json',
  'jsoncallback' : 'JSON_CALLBACK',
};


var flickrCountryConfig = {
  'photoset_id' : '72157663078275073', //72157665071236322
};

var flickrCaptainsConfig = {
	'photoset_id' : '72157665384904446',
};


var flickrWinnersConfig = {
	'photoset_id' : '72157663119850773',
};

