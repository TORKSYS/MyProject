/**
 * Created by KH2041 on 2/17/2016.
 */
var tData = {
    "roundTypes": ["Group", "Super-10", "Semi-Final", "Final"],

    "matchDates": ["8 March", "9 March", "10 March", "11 March", "12 March", "13 March", "15 March", "16 March", "17 March", "18 March", "19 March",
        "20 March", "21 March", "22 March", "23 March", "25 March", "26 March", "27 March", "28 March", "30 March", "31 March", "3 April"
    ],

    "teamNames": ["India", "Australia", "New Zealand", "Pakistan", "South Africa", "England", "West Indies", "Sri Lanka", "Hong Kong", "Bangladesh", "Netherlands", "Ireland", "Scotland", "Afghanistan", "Oman", "Zimbabwe", "TBD"],

    "groupsDetails" : ["GA" : {"T10", "T11", "T12", "T15"},
                "GB" : {"T9", "T13", "T14", "T16"},
                "G1" : {"T5", "T6", "T7", "T8"},
                "G2" : {"T1", "T2", "T3", "T4"}],
    
    "venueDetails": [{
        "venueId": "V1",
        "name": "Eden Gardens",
        "city": "Kolkata",
        "lat": 22.564668,
        "lng": 88.343307,
        "center": true
    }, {
        "venueId": "V2",
        "name": "M. Chinnaswamy Stadium",
        "city": "Bangalore",
        "lat": 12.978860,
        "lng": 77.599753
    }, {
        "venueId": "V3",
        "name": "Wankhede Stadium",
        "city": "Mumbai",
        "lat": 18.938863,
        "lng": 72.825795
    }, {
        "venueId": "V4",
        "name": "Himachal Pradesh Cricket Association Stadium",
        "city": "Dharamshala",
        "lat": 32.197573,
        "lng": 76.325874
    }, {
        "venueId": "V5",
        "name": "Feroz Shah Kotla Ground",
        "city": "New Delhi",
        "lat": 28.637726,
        "lng": 77.243316
    }, {
        "venueId": "V6",
        "name": "Punjab Cricket Association IS Bindra Stadium",
        "city": "Mohali",
        "lat": 30.690981,
        "lng": 76.737574
    }, {
        "venueId": "V7",
        "name": "Vidarbha Cricket Association Stadium",
        "city": "Nagpur",
        "lat": 21.013483,
        "lng": 79.039668
    }],

    "teamsDetails": [{
        "teamId": "T1",
        "country": "India",
        "group": "2",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/India.png",
        "teamLogo" : "img/1India.png",
        "captain": "MS Dhoni",
        "viceCaptain": "Virat Kohli",
        "wicketKeeper": "MS Dhoni",
        "players": ["MS Dhoni", "Ravichandran Ashwin", "Jasprit Bumrah", "Shikhar Dhawan", "Harbhajan Singh", "Ravindra Jadeja",
            "Virat Kohli", "Mohammed Shami", "Pawan Negi", "Ashish Nehra", "Hardik Pandya", "Ajinkya Rahane", "Suresh Raina", "Rohit Sharma", "Yuvraj Singh"
        ]
    }, {
        "teamId": "T2",
        "country": "Australia",
        "group": "2",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/Australia.png",
        "teamLogo" : "img/2Australia.png",
        "captain": "Steven Smith",
        "viceCaptain": "David Warner",
        "wicketKeeper": "Peter Nevill",
        "players": ["Steven Smith", "David Warner", "Ashton Agar", "Nathan Coulter-Nile", "James Faulkner", "Aaron Finch", "John Hastings",
            "Josh Hazlewood", "Usman Khawaja", "Mitchell Marsh", "Glenn Maxwell", "Peter Nevill", "Andrew Tye", "Shane Watson", "Adam Zampa"
        ]
    }, {
        "teamId": "T3",
        "country": "New Zealand",
        "group": "2",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/NewZealand.png",
        "teamLogo" : "img/3NewZealand.png",
        "captain": "Kane Williamson",
        "viceCaptain": "",
        "wicketKeeper": "Luke Ronchi",
        "players": ["Kane Williamson", "Corey Anderson", "Trent Boult", "Grant Elliott", "Martin Guptill", "Mitchell McClenaghan",
            "Nathan McCullum", "Adam Milne", "Colin Munro", "Henry Nicholls", "Luke Ronchi", "Mitchell Santner", "Ish Sodhi", "Tim Southee", "Ross Taylor"
        ]
    }, {
        "teamId": "T4",
        "country": "Pakistan",
        "group": "2",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/Pakistan.png",
        "teamLogo" : "img/4Pakistan.png",
        "captain": "Shahid Afridi",
        "viceCaptain": "",
        "wicketKeeper": "Sarfraz Ahmed",
        "players": ["Shahid Afridi", "Anwar Ali", "Babar Azam", "Iftikhar Ahmed", "Imad Wasim", "Khurram Manzoor", "Mohammad Amir", "Mohammad Hafeez",
            "Mohammad Irfan", "Mohammad Nawaz", "Rumman Raees", "Sarfraz Ahmed", "Shoaib Malik", "Umar Akmal", "Wahab Riaz"
        ]
    }, {
        "teamId": "T5",
        "country": "South Africa",
        "group": "1",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/SouthAfrica.png",
        "teamLogo" : "img/5SouthAfrica.png",
        "captain": "Faf du Plessis",
        "viceCaptain": "",
        "wicketKeeper": "Quinton de Kock",
        "players": ["Faf du Plessis", "Kyle Abbott", "Hashim Amla", "Farhaan Behardien", "Quinton de Kock", "AB de Villiers", "Jean-Paul Duminy", "Imran Tahir",
            "David Miller", "Chris Morris", "Aaron Phangiso", "Kagiso Rabada", "Rilee Rossouw", "Dale Steyn", "David Wiese"
        ]
    }, {
        "teamId": "T6",
        "country": "England",
        "group": "1",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/England.png",
        "teamLogo" : "img/6England.png",
        "captain": "Eoin Morgan",
        "viceCaptain": "",
        "wicketKeeper": "Jos Buttler",
        "players": ["Eoin Morgan", "Moeen Ali", "Sam Billings", "Jos Buttler", "Liam Dawson", "Steven Finn", "Alex Hales", "Chris Jordan", "Adil Rashid",
            "Joe Root", "Jason Roy", "Ben Stokes", "Reece Topley", "James Vince", "David Willey"
        ]
    }, {
        "teamId": "T7",
        "country": "West Indies",
        "group": "1",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/WestIndies.png",
        "teamLogo" : "img/7WestIndies.png",
        "captain": "Darren Sammy",
        "viceCaptain": "",
        "wicketKeeper": "Denesh Ramdin",
        "players": ["Darren Sammy", "Samuel Badree", "Sulieman Benn", "Carlos Brathwaite", "Dwayne Bravo", "Darren Bravo", "Andre Fletcher",
            "Chris Gayle", "Jason Holder", "Ashley Nurse", "Denesh Ramdin", "Andre Russell", "Marlon Samuels", "Lendl Simmons", "Jerome Taylor"
        ]
    }, {
        "teamId": "T8",
        "country": "Sri Lanka",
        "group": "1",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/SriLanka.png",
        "teamLogo" : "img/8SriLanka.png",
        "captain": "Angelo Mathews",
        "viceCaptain": "",
        "wicketKeeper": "Dinesh Chandimal",
        "players": ["Angelo Mathews", "TM Dilshan", "Lahiru Thirimanne", "Dimuth Karunaratne", "Dinesh Chandimal", "Kusal Perera", "Kithruwan Vithanage",
            "Lasith Malinga", "Thisara Perrera", "Dhammika Prasad", "Rangana Herath", "Nuwam Kulasekara", "Suranga Lakmal", "Jeevan Mendis", "Chameera"
        ]
    }, {
        "teamId": "T9",
        "country": "Hong Kong",
        "group": "B",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/HongKong.png",
        "teamLogo" : "img/9HongKong.png",
        "captain": "Tanwir Afzal",
        "viceCaptain": "",
        "wicketKeeper": "Jamie Atkinson",
        "players": ["Tanwir Afzal", "Aizaz Khan", "Anshy Rath", "Jamie Atkinson", "Babar Hayat", "Ryan Campbell", "Christopher Carter",
            "Mark Chapman", "Haseeb Amjad", "Nadeem Ahmed", "Nizakat Khan", "Kinchit Shah", "Tanveer Ahmed", "Waqas Barkat", "Waqas Khan"
        ]
    }, {
        "teamId": "T10",
        "country": "Bangladesh",
        "group": "A",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/Bangladesh.png",
        "teamLogo" : "img/10Bangladesh.png",
        "captain": "Mashrafe Mortaza",
        "viceCaptain": "Shakib Al Hasan",
        "wicketKeeper": "Mushfiqur Rahim",
        "players": ["Mashrafe Mortaza", "Shakib Al Hasan", "Abu Hider", "Al-Amin Hossain", "Arafat Sunny", "Mahmudullah", "Mohammad Mithun", "Mushfiqur Rahim",
            "Mustafizur Rahman", "Nasir Hossain", "Nurul Hasan", "Sabbir Rahman", "Soumya Sarkar", "Tamim Iqbal", "Taskin Ahmed", "Imrul Kayes", "Kamrul Islam Rabbi",
            "Muktar Ali", "Shuvagata Hom"
        ]
    }, {
        "teamId": "T11",
        "country": "Netherlands",
        "group": "A",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/Netherlands.png",
        "teamLogo" : "img/11Netherlands.png",
        "captain": "Wesley Barresi",
        "viceCaptain": "",
        "wicketKeeper": "",
        "players": ["Wesley Barresi", "Ahsan Malik", "Peter Borren", "Mudassar Bukhari", "Ben Cooper", "Vivian Kingma", "Stephan Myburgh", "Max ODowd",
            "Michael Rippon", "Pieter Seelaar", "Sikander Zulfiqar", "Logan van Beek", "Timm van der Gugten", "Roelof van der Merwe", "Paul van Meekeren"
        ]
    }, {
        "teamId": "T12",
        "country": "Ireland",
        "group": "A",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/Ireland.png",
        "teamLogo" : "img/12Ireland.png",
        "captain": "William Porterfield",
        "viceCaptain": "",
        "wicketKeeper": "Niall OBrien",
        "players": ["William Porterfield", "Andy Balbirnie", "George Dockrell", "Andy McBrine", "Tim Murtagh", "Kevin OBrien", "Niall OBrien", "Andrew Poynter",
            "Stuart Poynter", "Boyd Rankin", "Max Sorensen", "Paul Stirling", "Stuart Thompson", "Gary Wilson", "Craig Young"
        ]
    }, {
        "teamId": "T13",
        "country": "Scotland",
        "group": "B",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/Scotland.png",
        "teamLogo" : "img/13Scotland.png",
        "captain": "Preston Mommsen",
        "viceCaptain": "Kyle Coetzer",
        "wicketKeeper": "Matthew Cross",
        "players": ["Preston Mommsen", "Kyle Coetzer", "Richie Berrington", "Matthew Cross", "Josh Davey", "Con de Lange", "Alasdair Evans", "Michael Leask",
            "Matt Machan", "Calum MacLeod", "Gavin Main", "George Munsey", "Safyaan Sharif", "Rob Taylor", "Mark Watt"
        ]
    }, {
        "teamId": "T14",
        "country": "Afghanistan",
        "group": "B",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/Afghanistan.png",
        "teamLogo" : "img/14Afghanistan.png",
        "captain": "Asghar Stanikzai",
        "viceCaptain": "",
        "wicketKeeper": "Mohammad Shahzad",
        "players": ["Asghar Stanikzai", "Amir Hamza", "Dawlat Zadran", "Gulbadin Naib", "Hamid Hassan", "Karim Sadiq", "Mohammad Nabi", "Mohammad Shahzad",
            "Najibullah Zadran", "Noor Ali Zadran", "Rashid Khan", "Samiullah Shenwari", "Shafiqullah", "Shapoor Zadran", "Usman Ghani", "Mirwais Ashraf",
            "Najeeb Tarakai", "Rokhan Barakzai", "Yamin Ahmadzai"
        ]
    }, {
        "teamId": "T15",
        "country": "Oman",
        "group": "A",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/Oman.png",
        "teamLogo" : "img/15Oman.png",
        "captain": "Sultan Ahmed",
        "viceCaptain": "",
        "wicketKeeper": "Sultan Ahmed",
        "players": ["Sultan Ahmed", "Aamir Kaleem", "Amir Ali", "Munis Ansari", "Jatinder Singh", "Khawar Ali", "Ajay Lalcheta", "Mehran Khan", "Mohammad Nadeem",
            "Arun Poulose", "Rajeshkumar Ranpura", "Sufyan Mehmood", "Vaibhav Wategaonkar", "Yousuf Mahmood", "Zeeshan Maqsood", "Zeeshan Siddiqui"
        ]
    }, {
        "teamId": "T16",
        "country": "Zimbabwe",
        "group": "B",
        "championYears": "",
        "runnerupYears": "",
        "countryFlag": "img/Zimbabwe.png",
        "teamLogo" : "img/16Zimbabwe.png",
        "captain": "Hamilton Masakadza",
        "viceCaptain": "",
        "wicketKeeper": "Richmond Mutumbami",
        "players": ["Hamilton Masakadza", "Tendai Chatara", "Elton Chigumbura", "Tendai Chisoro", "Graeme Cremer", "Luke Jongwe", "Neville Madziva",
            "Wellington Masakadza", "Peter Moor", "Richmond Mutumbami", "Tinashe Panyangara", "Vusi Sibanda", "Sikandar Raza", "Malcolm Waller",
            "Sean Williams", "Donald Tiripano"
        ]
    }],


    "matchFixture": [{
        "matchesType": "R1",
        "matches": [{
            "matchId": "M1",
            "matchDate": "D1",
            "matchTime": "",
            "opp1": "T9",
            "opp2": "T16",
            "venueId": "V7"
        }, {
            "matchId": "M2",
            "matchDate": "D1",
            "matchTime": "",
            "opp1": "T14",
            "opp2": "T13",
            "venueId": "V7"
        }, {
            "matchId": "M3",
            "matchDate": "D2",
            "matchTime": "",
            "opp1": "T10",
            "opp2": "T11",
            "venueId": "V4"
        }, {
            "matchId": "M4",
            "matchDate": "D2",
            "matchTime": "",
            "opp1": "T12",
            "opp2": "T15",
            "venueId": "V4"
        }, {
            "matchId": "M5",
            "matchDate": "D3",
            "matchTime": "",
            "opp1": "T13",
            "opp2": "T16",
            "venueId": "V7"
        }, {
            "matchId": "M6",
            "matchDate": "D3",
            "matchTime": "",
            "opp1": "T9",
            "opp2": "T14",
            "venueId": "v7"
        }, {
            "matchId": "M7",
            "matchDate": "D4",
            "matchTime": "",
            "opp1": "T15",
            "opp2": "T11",
            "venueId": "V4"
        }, {
            "matchId": "M8",
            "matchDate": "D4",
            "matchTime": "",
            "opp1": "T10",
            "opp2": "T12",
            "venueId": "V4"
        }, {
            "matchId": "M9",
            "matchDate": "D5",
            "matchTime": "",
            "opp1": "T14",
            "opp2": "T16",
            "venueId": "V7"
        }, {
            "matchId": "M10",
            "matchDate": "D5",
            "matchTime": "",
            "opp1": "T9",
            "opp2": "T13",
            "venueId": "v7"
        }, {
            "matchId": "M11",
            "matchDate": "D6",
            "matchTime": "",
            "opp1": "T12",
            "opp2": "T11",
            "venueId": "V4"
        }, {
            "matchId": "M12",
            "matchDate": "D6",
            "matchTime": "",
            "opp1": "T10",
            "opp2": "T12",
            "venueId": "V4"
        }]
    }, {
        "matchesType": "R2",
        "matches": [{
            "matchId": "M13",
            "matchDate": "D7",
            "matchTime": "",
            "opp1": "T1",
            "opp2": "T3",
            "venueId": "V7"
        }, {
            "matchId": "M14",
            "matchDate": "D8",
            "matchTime": "",
            "opp1": "T6",
            "opp2": "T7",
            "venueId": "V1"
        }, {
            "matchId": "M15",
            "matchDate": "D8",
            "matchTime": "",
            "opp1": "T4",
            "opp2": "TA",
            "venueId": "V1"
        }, {
            "matchId": "M16",
            "matchDate": "D9",
            "matchTime": "",
            "opp1": "T8",
            "opp2": "TB",
            "venueId": "V1"
        }, {
            "matchId": "M17",
            "matchDate": "D10",
            "matchTime": "",
            "opp1": "T2",
            "opp2": "T3",
            "venueId": "V4"
        }, {
            "matchId": "M18",
            "matchDate": "D10",
            "matchTime": "",
            "opp1": "T6",
            "opp2": "T5",
            "venueId": "V3"
        }, {
            "matchId": "M19",
            "matchDate": "D11",
            "matchTime": "",
            "opp1": "T1",
            "opp2": "T4",
            "venueId": "V4"
        }, {
            "matchId": "M20",
            "matchDate": "D12",
            "matchTime": "",
            "opp1": "T5",
            "opp2": "TB",
            "venueId": "V3"
        }, {
            "matchId": "M21",
            "matchDate": "D12",
            "matchTime": "",
            "opp1": "T8",
            "opp2": "T7",
            "venueId": "V2"
        }, {
            "matchId": "M22",
            "matchDate": "D13",
            "matchTime": "",
            "opp1": "T2",
            "opp2": "TA",
            "venueId": "V2"
        }, {
            "matchId": "M23",
            "matchDate": "D14",
            "matchTime": "",
            "opp1": "T3",
            "opp2": "T4",
            "venueId": "V6"
        }, {
            "matchId": "M24",
            "matchDate": "D15",
            "matchTime": "",
            "opp1": "T6",
            "opp2": "TB",
            "venueId": "V5"
        }, {
            "matchId": "M25",
            "matchDate": "D15",
            "matchTime": "",
            "opp1": "T1",
            "opp2": "TA",
            "venueId": "V2"
        }, {
            "matchId": "M26",
            "matchDate": "D16",
            "matchTime": "",
            "opp1": "T2",
            "opp2": "T4",
            "venueId": "V6"
        }, {
            "matchId": "M27",
            "matchDate": "D16",
            "matchTime": "",
            "opp1": "T5",
            "opp2": "T7",
            "venueId": "V7"
        }, {
            "matchId": "M28",
            "matchDate": "D17",
            "matchTime": "",
            "opp1": "T3",
            "opp2": "TA",
            "venueId": "V1"
        }, {
            "matchId": "M29",
            "matchDate": "D17",
            "matchTime": "",
            "opp1": "T6",
            "opp2": "T8",
            "venueId": "V5"
        }, {
            "matchId": "M30",
            "matchDate": "D18",
            "matchTime": "",
            "opp1": "T1",
            "opp2": "T2",
            "venueId": "V6"
        }, {
            "matchId": "M31",
            "matchDate": "D18",
            "matchTime": "",
            "opp1": "T7",
            "opp2": "TB",
            "venueId": "V7"
        }, {
            "matchId": "M32",
            "matchDate": "D19",
            "matchTime": "",
            "opp1": "T5",
            "opp2": "T8",
            "venueId": "V5"
        }]
    }, {

        "matchesType": "R3",
        "matches": [{
            "matchId": "M33",
            "matchDate": "D20",
            "matchTime": "",
            "opp1": "TD",
            "opp2": "TD",
            "venueId": "V5"
        }, {
            "matchId": "M34",
            "matchDate": "D21",
            "matchTime": "",
            "opp1": "TD",
            "opp2": "TD",
            "venueId": "V3"
        }]
    }, {
        "matchesType": "R4",
        "matches": [{
            "matchId": "M35",
            "matchDate": "D22",
            "matchTime": "",
            "opp1": "TD",
            "opp2": "TD",
            "venueId": "V1"
        }]
    }

    ]
};
