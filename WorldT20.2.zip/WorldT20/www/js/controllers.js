angular.module('worldt20.controllers', ['worldt20.services'])

.controller('AppCtrl', function($scope, $ionicModal, $timeout, $q, $http) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};
  //$scope.flickrURL =
  $scope.teamlists = {};

  testRTypes = new Array();
  teamLogosList = new Array();

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})

.controller('TeamsDetailsCtrl', function($scope, T20Data, FlickrFactory, $http) {
  console.log('in TeamsDetailsCtrl');
  teamsInfo = T20Data.getTeamsDetails();
  var getPicsFlickrURL = FlickrFactory.getFlickrCountryURL();
  //console.log(' Flickr URL is ' + getPicsFlickrURL);
  $scope.teamlists = teamsInfo;
  $http.jsonp(getPicsFlickrURL)
  .success(function (data){
      console.log('in success');
      if(data.stat == 'ok') {
        revisedTeamsInfo = FlickrFactory.produceFlickrCountryURLs(data.photoset.photo);
        console.log('Displaying Team Logos from Flickr');
        $scope.countrylists = revisedTeamsInfo;
      }else if(data.stat == 'fail') {
        console.error('request failed error is ' + data.message);
      }
  })
  .error(function (error){
      console.log('in error ' + error);
  });
  //$scope.teamlists = teamsInfo;
})

.controller('TeamDetailsCtrl', function($scope, $stateParams, T20Data) {
  console.log('in TeamDetailsCtrl');
  teamInfo = T20Data.getTeamDetails($stateParams.tid);
  playersList = new Array();
  $scope.playersList = teamInfo.players;
  $scope.country = teamInfo.country;
})

.controller('HistoryCtrl', function($scope, HistoryFactory){
  console.log('in HistoryCtrl');
  var historyCollection = new Array();

  years = HistoryFactory.getHistoryYears();
  
  winners = HistoryFactory.getHistoryWinners();
  runners = HistoryFactory.getHistoryRunners();
  

  for(var i=0; i<years.length; i++) {
    var historyData = {};
    historyData.years = years[i];
    
    historyData.winners = winners[i];
    historyData.runners = runners[i];
    
    historyCollection[i] = historyData; 
  }

  $scope.historyCollections = historyCollection;

})

.controller('HistoryDetailsCtrl', function($scope, HistoryFactory, $stateParams){
  console.log('in HistoryDetailsCtrl');
  var historyCollection = new Array();

  years = HistoryFactory.getHistoryYears();
  hosts = HistoryFactory.getHistoryHosts();
  winners = HistoryFactory.getHistoryWinners();
  winnersPic = HistoryFactory.getHistoryWinnerPics();
  runners = HistoryFactory.getHistoryRunners();
  results = HistoryFactory.getHistoryResults();
  moms = HistoryFactory.getHistoryMOM();
  moss = HistoryFactory.getHistoryMOS();

  currentYear = $stateParams.hyear;
  var historyData = {};

  for(var i=0; i<years.length; i++) {
    if(currentYear == years[i]) {
    
      historyData.years = years[i];
      historyData.hosts = hosts[i];
      historyData.winners = winners[i];
      historyData.winnersPic = winnersPic[i];
      historyData.runners = runners[i];
      historyData.results = results[i];
      historyData.moms = moms[i];
      historyData.moss = moss[i];
      break;
    }
    
  }

  $scope.hdCollections = historyData;

})

.controller('RoundsListCtrl', function($scope, T20Data, FlickrFactory, $http){
  console.log('in RoundsListCtrl');
  testRTypes = T20Data.getMatchTypes();
  $scope.roundTypes = testRTypes;

  var getTeamPicsFlickrURL = FlickrFactory.getFlickrURL();
  $http.jsonp(getTeamPicsFlickrURL)
  .success(function (data){
      console.log('in success');
      if(data.stat == 'ok') {
        revisedTeamsLogos = FlickrFactory.produceFlickrURLs(data.photoset.photo);
        console.log('Displaying Team Logos from Flickr');
        teamLogosList = revisedTeamsLogos;
      }else if(data.stat == 'fail') {
        console.error('request failed error is ' + data.message);
      }
  })
  .error(function (error){
      console.log('in error ' + error);
  });
  console.log('teamLogosList ' + teamLogosList);
})

.controller('MatchesListsCtrl', function($scope, T20Data, FlickrFactory, HelperFunction, $stateParams, $http){
  console.log('in MatchesListsCtrl');
  
  var filledSchedule = new Array();
  

  fullSchedule = T20Data.getMatchesFixture();
  
  roundsInfo = T20Data.getMatchTypes();

  roundType = $stateParams.rtype;
  $scope.roundName = roundType;

  for(var i=0; i<roundsInfo.length; i++) {
    if(roundType == roundsInfo[i]) {
      currentRound = i;
      break;
    }
  }

  currentSchedule = fullSchedule[currentRound];
  currentMatchesList = currentSchedule.matches;
  var t1index = 1, t2index = 1;

  for(var i=0; i<currentMatchesList.length; i++) {
   
    fullFixture = HelperFunction.prepareFullFixture(currentMatchesList[i]);
    fullFixture.roundNumber = currentRound+1;
    filledSchedule[i] = fullFixture;
  }

  $scope.matchesFixture = filledSchedule;
})

.controller('MatchListsCtrl', function($scope, $stateParams, T20Data, HelperFunction){
  console.log('in MatchListsCtrl');
  rnumber = $stateParams.rtype;
  mnumber = $stateParams.mnumber;
  fullSchedule = T20Data.getMatchesFixture();
  //console.log('currentMatch is ' + fullSchedule[rnumber-1].matches[mnumber-1]);
  $scope.currentMatch = HelperFunction.prepareFullFixture(fullSchedule[rnumber-1].matches[mnumber-1]);
  console.log('currentMatch is ' + $scope.currentMatch);
});
